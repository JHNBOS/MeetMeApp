<?php 
 //Getting Id
 $name = $_GET['name'];
 $email= $_GET['email'];
 
 //Importing database
 require_once('dbConnect.php');
 
 //Creating sql query
 $sql = "DELETE FROM groupmembers WHERE group_name=$name AND email=$email;";
 
 //Deleting record in database 
 if(mysqli_query($con,$sql)){
 echo "$email";
 }else{
 echo 'Unable to delete groupmember. Please try again!';
 }
 
 //closing connection 
 mysqli_close($con);