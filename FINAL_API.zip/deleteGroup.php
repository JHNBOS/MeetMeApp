<?php 
 //Getting Id
 $name = $_GET['name'];
 
 //Importing database
 require_once('dbConnect.php');
 
 //Creating sql query
 $sql = "DELETE FROM groups WHERE name=$name;";
 
 //Deleting record in database 
 if(mysqli_query($con,$sql)){
 echo "$name";
 }else{
 echo 'Unable to delete group. Please try again!';
 }
 
 //closing connection 
 mysqli_close($con);