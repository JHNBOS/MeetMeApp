<?php 
 
	 //Getting values
	 $fname = $_POST['first_name'];
	 $lname = $_POST['last_name'];
	 $email = $_POST['email'];
	 $pass = $_POST['password'];
	 $color = $_POST['color'];
	 	 
	 //Importing our db connection script
	 require_once('dbConnect.php');
	 

	 //Check if exists
	 $sql = "SELECT * FROM user WHERE email='$email'";
	 $create = "INSERT INTO user(first_name, last_name, email, password, color) VALUES ('$fname','$lname', '$email', '$pass', '$color')";
	 $check = mysqli_query($con,$sql);
	 
	if($email == "" || $pass == "" || $fname == "" || $lname == "" || $color == ""){
	 	echo 'Please fill in all fields';
	} else{
	
		if(!$row = mysql_fetch_array($check)){
			$data = mysqli_query($con,$create);
			
			if($data){
				echo "$email";
			} else{
				echo 'Username or email is already in use!';
			}
		} else {
			echo 'Unable to add user. Please try again!';
		}
	}
	
	
	//Closing the database 
	mysqli_close($con);
 