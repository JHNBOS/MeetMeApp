<?php 
 
 //Getting values
 $username = $_POST['username'];
 $fname = $_POST['first_name'];
 $lname = $_POST['last_name'];
 $email = $_POST['email'];
 $pass = $_POST['password'];
 $color = $_POST['color'];
 
 //Creating an sql query
 $sql = "INSERT INTO user (username, first_name, last_name, email, password, color) VALUES ('$username','$fname','$lname', '$email', '$pass', '$color')";
 
 //Importing our db connection script
 require_once('dbConnect.php');
 
 //Executing query to database
 if(mysqli_query($con,$sql)){
 	echo "$email";
 }else if($email == ""){
 	echo 'Please fill in all fields';
 }else{
 	echo 'Unable to add user. Please try again!';
 }
 
 //Closing the database 
 mysqli_close($con);
 