<?php 
 
 //Getting values
 $name = $_GET['name'];
 $email = $_GET['email'];

 
 //Creating an sql query
 $sql = "INSERT INTO groupmembers (group_name, email) VALUES ('$name', '$email')";
 
 //Importing our db connection script
 require_once('dbConnect.php');
 
 //Executing query to database
 if(mysqli_query($con,$sql)){
 	echo "$name";
 } else if($name == ""){
 	echo 'Please select someone to add as groupmember!';
 }else{
 	echo 'Unable to add groupmember. Please try again!';
 }
 
 //Closing the database 
 mysqli_close($con);
 