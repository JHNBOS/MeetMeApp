<?php 
 
 //Getting values
 $name = $_GET['name'];
 $email = $_GET['email'];

 
 //Creating an sql query
 $sql = "INSERT INTO contacts (contact_email, email) VALUES ('$name', '$email')";
 
 //Importing our db connection script
 require_once('dbConnect.php');
 
 //Executing query to database
 if(mysqli_query($con,$sql)){
 echo "$name";
 }else{
 echo 'Unable to find contact. Please try again!';
 }
  
 //Closing the database 
 mysqli_close($con);
 
