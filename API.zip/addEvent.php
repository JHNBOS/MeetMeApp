<?php 
 
 //Getting values
 $title = $_POST['title'];
 $loc = $_POST['loc'];
 $start = $_POST['start'];
 $end = $_POST['end'];
 $creator = $_POST['creator'];
 $group = $_POST['grouip'];
 
 //Creating an sql query
 $sql = "INSERT INTO event (title, location, start, end, creator, group) VALUES ('$title','$loc','$start', '$end', '$creator', '$group')";
 
 //Importing our db connection script
 require_once('dbConnect.php');
 
 //Executing query to database
 if(mysqli_query($con,$sql)){
 echo "$title";
 }else{
 echo 'Unable to add event. Please try again!';
 }
 
 //Closing the database 
 mysqli_close($con);
 