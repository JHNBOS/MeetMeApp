<?php

	$fname = $_GET['first_name'];
	$lname = $_GET['last_name'];
	$color = $_GET['color'];

	$username = $_GET['username'];
	$password = $_GET['password'];
	$email = $_GET['email'];


	require_once('dbConnect.php');
	$sql = "SELECT * FROM user WHERE username='$username' OR email='$email'";
	
	$check = mysqli_fetch_array(mysqli_query($con,$sql));
	
	if(isset($check)){
		echo 'Username or email is already in use!';
	}else{				
		$sql = "INSERT INTO user (username, first_name, last_name, email, password, color) VALUES('$username', '$fname', '$lname', '$email', '$password','$color')";
		if(mysqli_query($con,$sql)){
			echo "$email";
		}else{
			echo 'Unable to register user. Please try again!';
		}
	}
	mysqli_close($con);
	