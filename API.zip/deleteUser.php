<?php 
 //Getting Id
 $id = $_GET['id'];
 
 //Importing database
 require_once('dbConnect.php');
 
 //Creating sql query
 $sql = "DELETE FROM user WHERE id=$id;";
 
 //Deleting record in database 
 if(mysqli_query($con,$sql)){
 echo 'Successfully deleted user!';
 }else{
 echo 'Unable to delete user. Please try again!';
 }
 
 //closing connection 
 mysqli_close($con);