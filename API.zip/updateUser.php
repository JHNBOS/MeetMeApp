<?php 
 if($_SERVER['REQUEST_METHOD']=='POST'){
 //Getting values 
 $username = $_POST['username'];
 $fname = $_POST['first_name'];
 $lname = $_POST['last_name'];
 $email = $_POST['email'];
 $pass = $_POST['password'];
 $color = $_POST['color'];
 
 //importing database connection script 
 require_once('dbConnect.php');
 
 //Creating sql query 
 $sql = "UPDATE user SET username = '$username', first_name = '$fname', last_name = '$lname', email= '$email', password = '$pass', color = '$color' WHERE id = $id;";
 
 //Updating database table 
 if(mysqli_query($con,$sql)){
 echo 'Succesfully updated user!';
 }else{
 echo 'Unable to update user. Please try again!';
 }
 
 //closing connection 
 mysqli_close($con);
 }