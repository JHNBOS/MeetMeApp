<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		$preturn = $email . $password;

		require_once('dbConnect.php');

		$sql = "select * from user where email='$email' and password='$password'";

		$check = mysqli_fetch_array(mysqli_query($con,$sql));

		if(isset($check)){
			echo "$preturn";
		}else{
			echo "Invalid username and/or password!";
		}

	}else{
		echo "Please try again!";
	}