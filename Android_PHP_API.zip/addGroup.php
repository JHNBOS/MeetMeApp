<?php 
 
	 //Getting values
	 
	$name = $_GET['name'];
	$email = $_GET['email'];
	 	 
	 //Importing our db connection script
	 require_once('dbConnect.php');
	 

	 //Check if exists
	 $sql = "SELECT * FROM groups WHERE name='$name'";
	 $create = "INSERT INTO groups (name, creator) VALUES ('$name', '$email')";
	 $check = mysqli_query($con,$sql);
	 
	if($email == "" || $name == ""){
	 	echo 'Please fill in all fields';
	} else{
	
		if(!$row = mysql_fetch_array($check)){
			$data = mysqli_query($con,$create);
			
			if($data){
				echo "$name ";
			} else{
				echo 'Group name is already in use!';
			}
		} else {
			echo 'Unable to create group. Please try again!';
		}
	}
	
	
	//Closing the database 
	mysqli_close($con);
 